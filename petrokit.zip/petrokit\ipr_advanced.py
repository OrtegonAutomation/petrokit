import numpy as np

def standing_ipr(p_res, q_max, pwf, n=1.8):
    """
    Modelo IPR de Standing (para reservorios con drive de gas en solución).
    
    Parámetros:
    -----------
    p_res : float
        Presión de yacimiento [psi]
    q_max : float
        Caudal máximo a pwf = 0 [STB/d]
    pwf : float o array
        Presión de fondo fluyente [psi]
    n : float
        Exponente empírico, típicamente entre 1.6 y 2.0 (default = 1.8)
    
    Retorna:
    --------
    q : float o array
        Caudal [STB/d]
    """
    return q_max * (1 - (pwf / p_res) ** n)


def jones_ipr(p_res, J, pwf, s=0):
    """
    Modelo IPR de Jones (para pozos fracturados).
    
    Parámetros:
    -----------
    p_res : float
        Presión de yacimiento [psi]
    J : float
        Índice de productividad [STB/d/psi]
    pwf : float o array
        Presión de fondo fluyente [psi]
    s : float
        Factor de daño/estimulación (s=0 pozo ideal, s<0 estimulado, s>0 dañado)
    
    Retorna:
    --------
    q : float o array
        Caudal [STB/d]
    """
    delta_p = p_res - pwf
    if (1 + s) <= 0:
        raise ValueError("El factor (1+s) debe ser positivo.")
    J_eff = J / (1 + s)
    return J_eff * delta_p


def ipr_curve(model, p_res, **kwargs):
    """
    Genera curvas IPR para cualquier modelo.
    
    model : función (ej. standing_ipr o jones_ipr)
    p_res : presión de yacimiento
    kwargs : parámetros del modelo
    
    Retorna:
    --------
    pwf_range, q_range
    """
    pwf_range = np.linspace(0, p_res, 30)
    q_range = [model(p_res, pwf=p, **kwargs) for p in pwf_range]
    return pwf_range, q_range
