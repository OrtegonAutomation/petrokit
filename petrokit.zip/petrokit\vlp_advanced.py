import numpy as np

# Conversiónes y constantes
STB_TO_FT3 = 5.615          # 1 STB = 5.615 ft3
MSCF_TO_FT3 = 1000.0        # 1 MSCF = 1000 ft3
G = 32.174                  # ft/s^2

def _stb_day_to_ft3_s(q_stb_day):
    return q_stb_day * STB_TO_FT3 / 86400.0

def _mscf_day_to_ft3_s(q_mscf_day):
    return q_mscf_day * MSCF_TO_FT3 / 86400.0

def beggs_brill_vlp(q_liq_stb_d,
                    q_gas_mscf_d,
                    d_in,
                    L_ft,
                    theta_deg,
                    rho_l,
                    rho_g,
                    mu_l,
                    mu_g,
                    f=0.02):
    """
    Versión simplificada (prototipo) orientada a Fase 2.
    Calcula una estimación de pwf (psi) para un caudal líquido y gas dados,
    usando una aproximación inspirada en Beggs & Brill + Darcy-Weisbach.

    Parámetros:
    - q_liq_stb_d: caudal líquido [STB/d]
    - q_gas_mscf_d: caudal gas [MSCF/d] (miles de ft3/d)
    - d_in: diámetro interior de tubing [in]
    - L_ft: longitud/columna equivalente [ft]
    - theta_deg: ángulo en grados (90=vertical). Se usa para elevación.
    - rho_l, rho_g: densidades [lb/ft3]
    - mu_l, mu_g: viscosidades [cP] (no usadas en esta versión simplificada)
    - f: factor de fricción (adimensional) — por ahora fijo (mejorar con Colebrook)

    Retorna:
    - pwf: presión estimada en fondo [psi] (delta presión por fricción + hidrostática)
    """

    # Convertir caudales a ft3/s
    ql = _stb_day_to_ft3_s(q_liq_stb_d)
    qg = _mscf_day_to_ft3_s(q_gas_mscf_d)

    # Área y velocidades superficiales
    d_ft = d_in / 12.0
    area = np.pi * (d_ft / 2.0) ** 2
    v_l = ql / area if area > 0 else 0.0
    v_g = qg / area if area > 0 else 0.0
    v_m = v_l + v_g

    # Holdup aproximado (simplificación prototipo):
    # usamos la fracción volumétrica superficial líquida como primera aproximación
    holdup = ql / (ql + qg) if (ql + qg) > 0 else 1.0
    holdup = np.clip(holdup, 0.0, 1.0)

    # Densidad media aproximada
    rho_m = holdup * rho_l + (1.0 - holdup) * rho_g  # lb/ft3

    # Pérdida por fricción (Darcy-Weisbach simplified) -> psi
    # Δp_fric = f * (L/D) * (rho_m/144) * (v_m^2 / (2*g))
    delta_p_fric = f * (L_ft / d_ft) * (rho_m / 144.0) * (v_m ** 2 / (2.0 * G))

    # Efecto hidrostático (elevación)
    elevation_ft = L_ft * np.sin(np.deg2rad(theta_deg))
    delta_p_hydro = (rho_m / 144.0) * elevation_ft

    # Presión estimada en fondo (pwf) relativa (simplificación)
    pwf = delta_p_fric + delta_p_hydro

    return pwf


def vlp_multiphase_curve(q_liq_range_stb_d,
                         q_gas_mscf_d,
                         d_in,
                         well_depth_ft,
                         rho_l,
                         rho_g,
                         mu_l,
                         mu_g,
                         f=0.02,
                         theta_deg=90.0):
    """
    Genera la curva VLP (pwf vs q_liq) usando beggs_brill_vlp simplificado.

    - q_liq_range_stb_d: array-like de caudales líquidos [STB/d]
    - q_gas_mscf_d: gas en MSCF/d (constante para la curva)
    - well_depth_ft: profundidad total [ft] (usado como L en aproximación)
    - theta_deg: ángulo general del pozo (90 = vertical)

    Retorna:
    - q_range (np.array), pwf_array (np.array)
    """
    q_range = np.asarray(q_liq_range_stb_d)
    pwf = np.array([beggs_brill_vlp(q, q_gas_mscf_d, d_in, well_depth_ft, theta_deg,
                                    rho_l, rho_g, mu_l, mu_g, f) for q in q_range])
    return q_range, pwf
